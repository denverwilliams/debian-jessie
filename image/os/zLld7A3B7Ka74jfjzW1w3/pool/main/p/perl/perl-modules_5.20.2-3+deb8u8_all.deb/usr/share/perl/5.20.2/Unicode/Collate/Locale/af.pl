+{
   locale_version => 1.01,
   entry => <<'ENTRY', # for DUCET v6.3.0
0149      ; [.174B.0020.0009] # LATIN SMALL LETTER N PRECEDED BY APOSTROPHE
ENTRY
};
